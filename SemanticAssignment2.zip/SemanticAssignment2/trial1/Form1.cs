﻿using Newtonsoft.Json;
using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;

namespace SemanticAssignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        string file;
        DataSet dataSet = new DataSet(); //Declaring a new dataset

        private void button3_Click(object sender, EventArgs e)
        {
			//********OPEN THE FILE************
			OpenFileDialog openFileDialog1 = new OpenFileDialog();

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox1.Text = openFileDialog1.FileName;
                file = openFileDialog1.FileName;
            }
        }

        //********LOADING XML IN DATAGRIDVIEW************
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //Loading the XML file and showing in dataGridView
                dataSet.ReadXml(@""+file);
                dataGridView1.DataSource = dataSet.Tables[0];
            }
            catch (Exception ex)
            {
                
if(ex is System.IO.FileNotFoundException) //Error handling for file missing or mispelled
                {
                    MessageBox.Show(file + " does not exist. Please check the name of the file again.");
                }
                else if(ex is System.Xml.XmlException) //Error handling if syntax error occurs in XML file
                {
                    MessageBox.Show(file + " has some XML syntax error.");
                }
            }
        }

        //********CONVERTING XML TO HTML************
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                XDocument xmlDocument = XDocument.Load(@""+file); //loading xml file

                XDocument result = new XDocument
                    //Designing HTML table to show XML data
                    (new XElement("table", new XAttribute("border", 1),
                            new XElement("thead",
                                new XElement("tr",
                                    new XElement("th", "Book ID"),
                                    new XElement("th", "Title"),
                                    new XElement("th", "Genre"),
                                    new XElement("th", "Description"),
                                    new XElement("th", "Author"),
                                    new XElement("th", "Price"),
                                    new XElement("th", "Published Date"))),
                            new XElement("tbody",
                            //Assigning attribute and element from XML into HTML tags
                                from emp in xmlDocument.Descendants("book")
                                select new XElement("tr",
                                            new XElement("td", emp.Attribute("id").Value),
                                            new XElement("td", emp.Element("title").Value),
                                            new XElement("td", emp.Element("genre").Value),
                                            new XElement("td", emp.Element("description").Value),
                                            new XElement("td", emp.Element("author").Value),
                                            new XElement("td", emp.Element("price").Value),
                                            new XElement("td", emp.Element("publish_date").Value)))));
                //Save the result in HTML format
                result.Save(@"C:\Users\aJue\Desktop\SEMANTIC assignment\SemanticAssignment2\HTML\xml2html.html");
                MessageBox.Show("XML - HTML sucessfully converted !");
                //Open the saved file location
                Process.Start("explorer.exe", @"C:\Users\aJue\Desktop\SEMANTIC assignment\SemanticAssignment2\HTML\");
             
            }
            catch(Exception ex)
            {
				//error message
				if (ex is System.IO.FileNotFoundException)
                {
                    MessageBox.Show(file + " does not exist. Please check the name of the file again."); //Error handling for file missing or mispelled
                }
                else if (ex is System.Xml.XmlException)
                {
                    MessageBox.Show(file + " has some XML syntax error."); //Error handling if syntax error occurs in XML file
                }
            }
        }
		//********CONVERT XML TO JSON************
		private void button4_Click(object sender, EventArgs e)
        {
			//create new document
            XmlDocument xDoc = new XmlDocument();

			//load xml into xdoc
			xDoc.LoadXml(File.ReadAllText(file));
			//to remove unecessary data
			xDoc.RemoveChild(xDoc.FirstChild);
			//saving the file
			string json = JsonConvert.SerializeXmlNode(xDoc);
            string[] lines = json.Split(new[] { "}," }, StringSplitOptions.None);
            using (System.IO.StreamWriter file =
            
				
				new System.IO.StreamWriter(@"C:\Users\aJue\Desktop\SEMANTIC assignment\SemanticAssignment2\Json\xml2json.txt"))
            {
				//formating the json file
				for (int i = 0; i < lines.Length; i++)
                {
                        file.WriteLine(lines[i]+"},");
                }
            }

            MessageBox.Show("XML - Json sucessfully converted !");
            //Open the saved json file location
            Process.Start("explorer.exe", @"C:\Users\aJue\Desktop\SEMANTIC assignment\SemanticAssignment2\Json\");
        }

        //********CONVERTING XML TO EXCEL************
        private void button5_Click(object sender, EventArgs e)
        {
            //Declaring libraries
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            DataSet ds = new DataSet();
            XmlReader xmlFile;
            int i = 0;
            int j = 0;

            xlApp = new Excel.ApplicationClass();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            //Opening XML file to read
            xmlFile = XmlReader.Create(file, new XmlReaderSettings());
            ds.ReadXml(xmlFile);

            //Assigning each data from DataSet(ds) into row and collums of excel
            for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
            {
                for (j = 0; j <= ds.Tables[0].Columns.Count - 1; j++)
                {
                    xlWorkSheet.Cells[i + 1, j + 1] = ds.Tables[0].Rows[i].ItemArray[j].ToString();
                }
            }

            //saving the excel file
            xlWorkBook.SaveAs(@"C:\Users\aJue\Desktop\SEMANTIC assignment\SemanticAssignment2\Excel\xml2excel.xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            releaseObject(xlApp);
            releaseObject(xlWorkBook);
            releaseObject(xlWorkSheet);

            MessageBox.Show("XML - Excel sucessfully converted !");
            //Open the saved (excel) file location
            Process.Start("explorer.exe", @"C:\Users\aJue\Desktop\SEMANTIC assignment\SemanticAssignment2\Excel\");

        }

		//exception handling for excel converter
        private void releaseObject(object obj)
        {
			
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }

        //**********RESET FUNCTION**************
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                dataSet.Tables[0].Clear();
                dataGridView1.DataSource= dataSet.Tables[0];
            }
            catch(System.IndexOutOfRangeException)
            {
                MessageBox.Show("Error occured !");
            }

            
        }
    }
}
